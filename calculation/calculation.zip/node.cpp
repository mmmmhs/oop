#include "node.h"
using namespace std;

Node::~Node(){}

void PlaceholderNode::set_val(float val)
{
    value_ = val;
}

void PlaceholderNode::calc(){}


