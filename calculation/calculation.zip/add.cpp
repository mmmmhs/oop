#include "add.h"

add::~add() = default;

void add::UpdateValue(){
    value_ = input1->value() + input2->value();
}